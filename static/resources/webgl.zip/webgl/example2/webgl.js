"use strict";

function getShader(gl, id) {
  var element = document.getElementById(id);
  var getType = {
    'x-shader/x-vertex' : gl.VERTEX_SHADER,
    'x-shader/x-fragment' : gl.FRAGMENT_SHADER,
  };
  var type, source, shader;

  if (!element) {
    console.log('Shader ' + id + ' not found.');
    return null;
  }

  source = element.text;
  type = getType[element.type];

  if (!type) {
    console.log('Unknown shader type ' + element.type);
    return null;
  }

  shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.log('Failed to compile the shader: ' + gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }

  return shader;
}

function createProgram(gl, vertex, fragment) {
  var program = gl.createProgram();

  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.log('Failed to link the program: ' + gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }

  return program;
}

function resize(gl, width, height) {
  if (gl.canvas.width == width && gl.canvas.height == height) {
    return
  }
  gl.canvas.width = width;
  gl.canvas.height = height;
  gl.viewport(0, 0, width, height);
}

function main() {
  var canvas = document.getElementById('glCanvas');
  var gl = canvas.getContext('webgl');

  if (!gl) {
    console.log('Unable to initialize WebGL. Your browser may not support it.');
    return;
  }

  var program = createProgram(gl,
                              getShader(gl, 'vertex'),
                              getShader(gl, 'fragment'));
  var positionAttribute = gl.getAttribLocation(program, 'aPosition');
  var resolutionUniform = gl.getUniformLocation(program, 'uResolution');
  var colorUniform = gl.getUniformLocation(program, 'uColor');
  var pointsBuffer = gl.createBuffer();

  resize(gl, canvas.clientWidth, canvas.clientHeight);
  gl.clearColor(0.0, 0.0, 0.0, 0.0)
  gl.clear(gl.COLOR_BUFFER_BIT);

  gl.useProgram(program);

  gl.enableVertexAttribArray(positionAttribute);
  gl.bindBuffer(gl.ARRAY_BUFFER, pointsBuffer);
  gl.vertexAttribPointer(positionAttribute, 2, gl.FLOAT, false, 0, 0);
  gl.uniform2f(resolutionUniform, gl.canvas.width, gl.canvas.height);

  for (var i = 0; i != 50; ++i) {
    var x = Math.floor(Math.random() * canvas.clientWidth);
    var y = Math.floor(Math.random() * canvas.clientHeight);
    var w = Math.floor(Math.random() * (canvas.clientWidth - x));
    var h = Math.floor(Math.random() * (canvas.clientHeight - y));
    var points = new Float32Array([
      x,     y,
      x + w, y,
      x + w, y + h,
      x + w, y + h,
      x,     y + h,
      x,     y,
    ]);

    gl.bufferData(gl.ARRAY_BUFFER, points, gl.STATIC_DRAW);
    gl.uniform4f(colorUniform, Math.random(), Math.random(), Math.random(), 1);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }
}
