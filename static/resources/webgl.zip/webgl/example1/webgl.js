"use strict";

function getShader(gl, id) {
  var element = document.getElementById(id);
  var getType = {
    'x-shader/x-vertex' : gl.VERTEX_SHADER,
    'x-shader/x-fragment' : gl.FRAGMENT_SHADER,
  };
  var type, source, shader;

  if (!element) {
    console.log('Shader ' + id + ' not found.');
    return null;
  }

  source = element.text;
  type = getType[element.type];

  if (!type) {
    console.log('Unknown shader type ' + element.type);
    return null;
  }

  shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.log('Failed to compile the shader: ' + gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }

  return shader;
}

function createProgram(gl, vertex, fragment) {
  var program = gl.createProgram();

  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.log('Failed to link the program: ' + gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }

  return program;
}

function resize(gl, width, height) {
  if (gl.canvas.width == width && gl.canvas.height == height) {
    return
  }
  gl.canvas.width = width;
  gl.canvas.height = height;
  gl.viewport(0, 0, width, height);
}

function setup() {
  var canvas = document.getElementById('glCanvas');
  var gl = canvas.getContext('webgl');

  if (!gl) {
    console.log('Unable to initialize WebGL. Your browser may not support it.');
    return;
  }

  var program = createProgram(gl,
                              getShader(gl, 'vertex'),
                              getShader(gl, 'fragment'));
  var positionAttribute = gl.getAttribLocation(program, 'aPosition');
  var buffer = gl.createBuffer();
  var triangle = [0.0, 0.0, 0.0, 0.5, 0.7, 0.0,];

  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(triangle), gl.STATIC_DRAW);


  resize(gl, canvas.clientWidth, canvas.clientHeight);
  gl.clearColor(0.0, 0.0, 0.0, 0.0)
  gl.clear(gl.COLOR_BUFFER_BIT);

  gl.useProgram(program);

  gl.enableVertexAttribArray(positionAttribute);
  gl.vertexAttribPointer(positionAttribute, 2, gl.FLOAT, false, 0, 0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
}
