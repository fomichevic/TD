"use strict";

function getShader(gl, id) {
  var element = document.getElementById(id);
  var getType = {
    'x-shader/x-vertex' : gl.VERTEX_SHADER,
    'x-shader/x-fragment' : gl.FRAGMENT_SHADER,
  };
  var type, source, shader;

  if (!element) {
    console.log('Shader ' + id + ' not found.');
    return null;
  }

  source = element.text;
  type = getType[element.type];

  if (!type) {
    console.log('Unknown shader type ' + element.type);
    return null;
  }

  shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.log('Failed to compile the shader: ' + gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }

  return shader;
}

function createProgram(gl, vertex, fragment) {
  var program = gl.createProgram();

  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.log('Failed to link the program: ' + gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }

  return program;
}

function resize(gl, width, height) {
  if (gl.canvas.width == width && gl.canvas.height == height) {
    return
  }
  gl.canvas.width = width;
  gl.canvas.height = height;
  gl.viewport(0, 0, width, height);
}

function draw(gl, canvas, image) {
  var program = createProgram(gl,
                              getShader(gl, 'vertex'),
                              getShader(gl, 'fragment'));

  var positionAttrib = gl.getAttribLocation(program, 'aPosition');
  var texturePositionAttrib = gl.getAttribLocation(program, 'aTexturePosition');

  var resolutionUniform = gl.getUniformLocation(program, 'uResolution');
  var textureUniform = gl.getUniformLocation(program, 'uTexture');

  var pointsBuffer = gl.createBuffer();
  var points = new Float32Array([
    0, 0,
    canvas.clientWidth, 0,
    canvas.clientWidth, canvas.clientHeight,
    canvas.clientWidth, canvas.clientHeight,
    0, canvas.clientHeight,
    0, 0,
    canvas.clientWidth / 3.0, canvas.clientHeight / 3.0,
    2.0 * canvas.clientWidth / 3.0, canvas.clientHeight / 3.0,
    2.0 * canvas.clientWidth / 3.0, 2.0 * canvas.clientHeight / 3.0,
    2.0 * canvas.clientWidth / 3.0, 2.0 * canvas.clientHeight / 3.0,
    canvas.clientWidth / 3.0, 2.0 * canvas.clientHeight / 3.0,
    canvas.clientWidth / 3.0, canvas.clientHeight / 3.0,
  ]);
  gl.bindBuffer(gl.ARRAY_BUFFER, pointsBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, points, gl.STATIC_DRAW);

  var texturePointsBuffer = gl.createBuffer();
  var texturePoints = new Float32Array([
    0, 0,
    1, 0,
    1, 1,
    1, 1,
    0, 1,
    0, 0,
    0, 0,
    1, 0,
    1, 1,
    1, 1,
    0, 1,
    0, 0,
  ]);
  gl.bindBuffer(gl.ARRAY_BUFFER, texturePointsBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, texturePoints, gl.STATIC_DRAW);

  var texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
  gl.generateMipmap(gl.TEXTURE_2D);

  resize(gl, canvas.clientWidth, canvas.clientHeight);
  gl.useProgram(program);
  gl.clearColor(0.0, 0.0, 0.0, 0.0);
  gl.clear(gl.COLOR_BUFFER_BIT);

  gl.enable(gl.BLEND);
  gl.blendEquation(gl.FUNC_ADD);
  gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

  gl.uniform2f(resolutionUniform, gl.canvas.width, gl.canvas.height);

  gl.enableVertexAttribArray(positionAttrib);
  gl.bindBuffer(gl.ARRAY_BUFFER, pointsBuffer);
  gl.vertexAttribPointer(positionAttrib, 2, gl.FLOAT, false, 0, 0);

  gl.enableVertexAttribArray(texturePositionAttrib);
  gl.bindBuffer(gl.ARRAY_BUFFER, texturePointsBuffer);
  gl.vertexAttribPointer(texturePositionAttrib, 2, gl.FLOAT, false, 0, 0);

  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.uniform1i(textureUniform, 0);

  gl.drawArrays(gl.TRIANGLES, 0, 12);
}

function main() {
  var canvas = document.getElementById('glCanvas');
  var gl = canvas.getContext('webgl');

  if (!gl) {
    console.log('Unable to initialize WebGL. Your browser may not support it.');
    return;
  }

  var image = new Image();

  image.onload = function() {
    draw(gl, canvas, image);
  }
  image.src = 'tower.png';
}
